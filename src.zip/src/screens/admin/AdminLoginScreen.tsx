import React, { useState } from 'react';
import { ActivityIndicator, Alert, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AdminStackParamList } from '../../navigation/AdminStack';
import { useAdmin } from '../../context/AdminContext';
import { ui, GREEN } from './adminUi';

type Props = NativeStackScreenProps<AdminStackParamList, 'AdminLogin'>;

export default function AdminLoginScreen({ navigation }: Props) {
  const { admins, loading, resetDemoData } = useAdmin();
  const [email, setEmail] = useState('rahman@complex1.demo');
  const [password, setPassword] = useState('123456');
  const [resetting, setResetting] = useState(false);

  const login = () => {
    if (loading) {
      Alert.alert('Please wait', 'Admin demo accounts are still loading.');
      return;
    }

    const normalizedEmail = email.trim().toLowerCase();
    const normalizedPassword = password.trim();
    const user = admins.find(a =>
      a.email.trim().toLowerCase() === normalizedEmail &&
      a.password === normalizedPassword &&
      a.isActive,
    );

    if (!user) {
      Alert.alert(
        'Login failed',
        'Email/password match nahi hua ya account inactive hai. Demo accounts reload karke dobara try karein.',
      );
      return;
    }

    if (user.role === 'sport_admin') {
      navigation.replace('SportAdminDashboard', { adminId: user.id });
    } else {
      navigation.replace('AdminDashboard', { adminId: user.id, complexId: user.complexId });
    }
  };

  const reloadDemoAccounts = () => {
    Alert.alert(
      'Reload demo accounts?',
      'This will replace locally saved Admin Panel demo data with the sample Complex 1 and Complex 2 accounts. Your player bookings are not affected.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reload',
          onPress: async () => {
            try {
              setResetting(true);
              await resetDemoData();
              setEmail('rahman@complex1.demo');
              setPassword('123456');
              Alert.alert('Demo accounts loaded', 'Now login with rahman@complex1.demo and password 123456.');
            } catch (error) {
              Alert.alert('Error', 'Demo accounts reload nahi ho paye. Please try again.');
            } finally {
              setResetting(false);
            }
          },
        },
      ],
    );
  };

  return (
    <View style={[ui.screen, { justifyContent: 'center', padding: 22 }]}>
      <View style={{ backgroundColor: GREEN, padding: 24, borderRadius: 22, marginBottom: 24 }}>
        <Text style={{ color: '#D1FAE5', fontSize: 12, fontWeight: '800' }}>SPORTSARENA</Text>
        <Text style={{ color: '#FFFFFF', fontSize: 27, fontWeight: '900', marginTop: 8 }}>Admin Login</Text>
        <Text style={{ color: '#D1FAE5', fontSize: 13, marginTop: 5 }}>Complex Admin & Sport Subadmin</Text>
      </View>

      <Text style={ui.label}>Email</Text>
      <TextInput
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        autoCorrect={false}
        keyboardType="email-address"
        style={ui.input}
        placeholder="Admin email"
        placeholderTextColor="#9AA69D"
      />

      <Text style={ui.label}>Password</Text>
      <TextInput
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        autoCapitalize="none"
        style={ui.input}
        placeholder="Password"
        placeholderTextColor="#9AA69D"
      />

      <TouchableOpacity
        style={[ui.button, { marginTop: 22, opacity: loading || resetting ? 0.6 : 1 }]}
        disabled={loading || resetting}
        onPress={login}
      >
        {loading ? <ActivityIndicator color="#FFFFFF" /> : <Text style={ui.buttonText}>Login to Admin Panel</Text>}
      </TouchableOpacity>

      <View style={[ui.card, { marginTop: 20 }]}>
        <Text style={ui.title}>Demo Complex Admin</Text>
        <Text style={ui.sub}>Complex 1: rahman@complex1.demo</Text>
        <Text style={ui.sub}>Complex 2: vijay@complex2.demo</Text>
        <Text style={ui.sub}>Password: 123456</Text>
        <Text style={[ui.title, { marginTop: 12 }]}>Demo Sport Subadmin</Text>
        <Text style={ui.sub}>Complex 1 Cricket: user1.cricket.c1@demo.com</Text>
        <Text style={ui.sub}>Password: 123456</Text>
      </View>

      <TouchableOpacity
        onPress={reloadDemoAccounts}
        disabled={loading || resetting}
        style={{ alignSelf: 'center', padding: 14, marginTop: 8 }}
      >
        <Text style={{ color: GREEN, fontSize: 13, fontWeight: '800' }}>
          {resetting ? 'Reloading demo accounts...' : 'Reload / Reset Demo Accounts'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}
