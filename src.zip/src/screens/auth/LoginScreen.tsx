import React, { useState } from 'react';
import {
  View,
  StyleSheet,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from 'react-native';

import { NativeStackScreenProps } from '@react-navigation/native-stack';

import ScreenWrapper from '../../components/ScreenWrapper';
import AppText from '../../components/AppText';
import AppInput from '../../components/AppInput';
import AppButton from '../../components/AppButton';

import { AuthStackParamList } from '../../navigation/types';
import { useAuth } from '../../context/AuthContext';

import { Colors, Spacing } from '../../theme';

type Props = NativeStackScreenProps<AuthStackParamList, 'Login'>;

const LoginScreen: React.FC<Props> = ({ navigation }) => {
  const { login } = useAuth();

  const [email, setEmail] = useState('demo@sports.com');
  const [password, setPassword] = useState('123456');

  const handleLogin = () => {
    if (!email.trim() || !password) {
      Alert.alert('Validation', 'Please enter email and password');
      return;
    }

    const success = login(email, password);

    if (!success) {
      Alert.alert('Login Failed', 'Invalid email or password');
    }
  };

  return (
    <ScreenWrapper>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.content}
        >
          <View style={styles.logoContainer}>
            <View style={styles.logo}>
              <AppText color={Colors.white} variant="h1">
                G
              </AppText>
            </View>

            <AppText variant="h2">GMR</AppText>

            <AppText color={Colors.textSecondary}>
              Your game. Your ground. Your time.
            </AppText>
          </View>

          <View style={styles.form}>
            <AppText variant="h1">Welcome Back!</AppText>

            <AppText color={Colors.textSecondary} style={styles.subtitle}>
              Login to book your favourite sports ground.
            </AppText>

            <AppInput
              label="Email Address"
              placeholder="Enter your email"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
            />

            <AppInput
              label="Password"
              placeholder="Enter your password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
            />

            <TouchableOpacity style={styles.forgot}>
              <AppText color={Colors.accent} variant="bodyMedium">
                Forgot Password?
              </AppText>
            </TouchableOpacity>

            <AppButton
              title="Login"
              onPress={handleLogin}
              style={styles.loginButton}
            />

            <View style={styles.footer}>
              <AppText color={Colors.textSecondary}>
                Don't have an account?{' '}
              </AppText>

              <TouchableOpacity onPress={() => navigation.navigate('Signup')}>
                <AppText color={Colors.accentDark} variant="bodyMedium">
                  Sign Up
                </AppText>
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={styles.adminLogin}
              onPress={() => navigation.navigate('Admin')}
              activeOpacity={0.8}
            >
              <AppText color={Colors.accentDark} variant="bodyMedium">
                Login as Complex / Sport Admin
              </AppText>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenWrapper>
  );
};

const styles = StyleSheet.create({
  content: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingVertical: 30,
  },

  logoContainer: {
    alignItems: 'center',
    marginBottom: 45,
    gap: 10,
  },

  logo: {
    width: 70,
    height: 70,
    borderRadius: 22,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },

  form: {
    width: '100%',
  },

  subtitle: {
    marginTop: 8,
    marginBottom: 30,
    lineHeight: 22,
  },

  forgot: {
    alignSelf: 'flex-end',
    marginBottom: 22,
  },

  loginButton: {
    marginTop: 5,
  },

  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 28,
  },

  demo: {
    textAlign: 'center',
    marginTop: 25,
  },

  adminLogin: {
    alignSelf: 'center',
    marginTop: 22,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
});

export default LoginScreen;
